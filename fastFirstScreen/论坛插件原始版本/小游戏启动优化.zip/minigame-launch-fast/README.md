# 小游戏启动优化

## 使用方式

把图片命名为`first.jpg`放入settings文件根目录即可
