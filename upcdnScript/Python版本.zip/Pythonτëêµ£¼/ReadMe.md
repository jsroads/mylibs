## 使用说明

1. 使用脚本运行 `python3 cdn_main.py`
2. 依次根据提示输入对应目录以及规则
3. 等待完成

```
Last login: Sat Jul 27 14:32:08 on ttys000
YDC012deMac-mini~/TestCase/Python/hot_cdn_plus(main|●6✚2…) % python3 cdn_main.py
请输入上一个版本的remote目录路径: /Users/ydc012/Downloads/old
请输入当前要热更版本的remote目录路径: /Users/ydc012/Downloads/new
请输入要分类的后缀名（多个后缀用逗号分隔，直接回车统计所有后缀）:
请输入排序规则 (默认从大到小排序，输入N从小到大排序):
请输入要添加的URL前缀: https://cdnminigame.lightlygame.com/tcs/mini/wx/publish/wechatgame_release/remote
已清空目录: output
YDC012deMac-mini~/TestCase/Python/hot_cdn_plus(main|●6✚2…) %
```

### 说明

- **get_valid_directory**: 获取并验证用户输入的目录路径。
- **compare_directories**: 比较两个目录，生成新的文件列表和现有文件列表。
- **classify_files_by_extension**: 根据文件后缀名分类文件。
- **sort_files_by_size**: 按文件大小排序文件列表。
- **add_url_prefix**: 为文件路径添加URL前缀。
- **save_classified_files**: 将分类后的文件路径保存到输出目录的文本文件中。**output目录**：如果`output`目录不存在，则创建该目录，并将每个后缀的文件列表保存到相应的`.txt`文件中。