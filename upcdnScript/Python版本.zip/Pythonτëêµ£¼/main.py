import os
import shutil


def get_valid_directory(prompt):
    while True:
        path = input(prompt).strip().replace(" ", "")
        if not os.path.exists(path):
            print(f"路径不存在: {path}")
        elif not os.path.isdir(path):
            print(f"这不是一个有效的目录: {path}")
        else:
            return path


def compare_directories(prev_dir, curr_dir):
    new_files = []
    existing_files = []

    for root, _, files in os.walk(curr_dir):
        for file in files:
            curr_file_path = os.path.join(root, file)
            rel_path = os.path.relpath(curr_file_path, curr_dir)
            prev_file_path = os.path.join(prev_dir, rel_path)

            if not os.path.exists(prev_file_path):
                new_files.append(curr_file_path)
            else:
                existing_files.append(curr_file_path)

    return new_files, existing_files


def classify_files_by_extension(files, extensions):
    classified_files = {ext: [] for ext in extensions}
    other_files = []

    for file in files:
        _, ext = os.path.splitext(file)
        ext = ext.lower()
        if ext in classified_files:
            classified_files[ext].append(file)
        else:
            other_files.append(file)

    return classified_files, other_files


def sort_files_by_size(files, descending=True):
    return sorted(files, key=lambda file: os.path.getsize(file), reverse=descending)


def add_url_prefix(files, prefix, base_path):
    return [os.path.join(prefix, os.path.relpath(file, base_path)) for file in files]


def save_classified_files(classified_files):
    output_dir = "output"

    # 清空 output 目录
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
        print(f"已清空目录: {output_dir}")
    os.makedirs(output_dir)

    for ext, files in classified_files.items():
        file_path = os.path.join(output_dir, f"{ext[1:]}.txt")
        with open(file_path, 'w') as f:
            for file in files:
                f.write(f"{file}\n")


def main():
    previous_version_path = get_valid_directory("请输入上一个版本的remote目录路径: ")
    current_version_path = get_valid_directory("请输入当前要热更版本的remote目录路径: ")

    new_files, existing_files = compare_directories(previous_version_path, current_version_path)

    extensions_input = input("请输入要分类的后缀名（多个后缀用逗号分隔，直接回车统计所有后缀）: ").strip()
    if extensions_input:
        extensions = extensions_input.split(',')
        extensions = [ext.strip().lower() if ext.startswith('.') else '.' + ext.strip().lower() for ext in extensions]
    else:
        extensions = set(os.path.splitext(file)[1].lower() for file in new_files)

    classified_files, other_files = classify_files_by_extension(new_files, extensions)

    sort_order = input("请输入排序规则 (默认从大到小排序，输入N从小到大排序): ").strip().upper()
    descending = sort_order != 'N'

    for ext, files in classified_files.items():
        classified_files[ext] = sort_files_by_size(files, descending=descending)

    url_prefix = input("请输入要添加的URL前缀: ").strip()
    for ext, files in classified_files.items():
        classified_files[ext] = add_url_prefix(files, url_prefix, current_version_path)

    save_classified_files(classified_files)


if __name__ == "__main__":
    main()
